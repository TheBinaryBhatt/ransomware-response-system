# backend/triage_service/models.py
from core.models import TriageIncident  # Import shared model
# No local definition needed