# backend/triage_service/routes.py

from fastapi import APIRouter, HTTPException
from .local_ai.triage_agent import triage_agent
from .models import TriageIncident
from core.database import get_db_session as get_db

router = APIRouter()


@router.post("/analyze")
async def analyze_incident(payload: dict):
    """
    Unified triage endpoint with guaranteed fallback.
    Ensures triage_agent receives a normalized incident dict.
    """
    try:
        incident_id = payload.get("incident_id")
        if not incident_id:
            raise ValueError("Missing incident_id in payload")

        # Normalize payload for triage_agent
        incident = {
            "id": incident_id,
            "source_ip": payload.get("source_ip"),
            "file_hash": payload.get("file_hash"),
            "file_path": payload.get("file_path"),
            "file_bytes": payload.get("file_bytes"),
            "severity": payload.get("severity", "high"),  # default if missing
            "description": payload.get("description", ""),
        }

        # Always returns a valid result (LLM optional)
        result = await triage_agent.analyze_incident(incident)

        # Correct async DB write
        async for db in get_db():
            TriageIncident.store_result(db, incident_id, result)
            break

        return {"status": "ok", "result": result}

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
