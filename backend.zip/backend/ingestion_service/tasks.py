# This service does not use Celery anymore.
# Ingestion is fully handled via FastAPI + RabbitMQ event bus.
